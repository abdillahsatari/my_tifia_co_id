<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Kit extends CI_Controller
{

	function __construct()
	{
		parent::__construct();
		cekLogin();
		// $this->load->model([]);
	}

	public function index()
	{
		$this->compro();
	}

	public function compro()
	{
		$data['title'] = 'Company Profile';
		$data['link'] = [
			['judul' => 'Download company profile', 'link' => base_url('uploads/marketing-kit/company_profile.pdf')]
		];

		$this->viewku->title("Company Profile");
		$this->viewku->view("kit/link_download.php", $data);
	}

	public function productknowledge()
	{
		$data['title'] = 'Product Knowledge';
		$data['link'] = [
			['judul' => 'Download Trading Rules - SPA', 'link' => base_url('uploads/marketing-kit/trading_rules_spa.pdf')],
			['judul' => 'Download Trading Rules - Multilateral', 'link' => base_url('uploads/marketing-kit/trading_rules_multilateral.pdf')]
		];

		$this->viewku->title("Company Profile");
		$this->viewku->view("kit/link_download.php", $data);
	}
}
